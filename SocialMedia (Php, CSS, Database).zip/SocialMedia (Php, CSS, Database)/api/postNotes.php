<?php
	//set the kind of data we're sending back 
	header("Content-Type: application/json");
	require_once "../credentials.php";
	//create 'empty' class that use when casting other types to objects
	$response=new \stdClass();
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	//get username
	//get title
	//get content
	$users=$_POST["user"];
	$title=$_POST["title"];
	$content=$_POST["content"];

	//create loop to record all checked user 
	foreach($users as $user){
		$sql = "INSERT INTO notes VALUES (NULL,'$title',now(),'$content','$user')";
		$result = mysqli_query($connection, $sql);
		if ($result){
			if (mysqli_affected_rows($connection) == 1)
			{	
			// set the kind of data we're sending back and a success code
				header("Content-Type: application/json", NULL, 201);
				$response->result="Success";
			}
			else
			{	// set the kind of data we're sending back and an error response code
				$response->result="No Record Found";
				header("Content-Type: application/json", NULL, 400);
			}
		}

		else{
			//if no $result available
			$response->result="Error";
			$response->message=mysqli_error($connection);
		}
	}
	
?>