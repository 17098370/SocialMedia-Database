<?php
//set the kind of data we're sending back 
require_once "../credentials.php";
//create 'empty' class that use when casting other types to objects
$response=new \stdClass();
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!isset($_POST['id']))
{ 
	// if  notreceived post['id'] (status's id) form global_feed."php"
	// set the kind of data we're sending back and an error response code
	header("Content-Type: application/json", NULL, 400);
	$response->status="error";
	$response->message="No status id submitted";
	// and send
	echo json_encode($response);
	// and exit this script
	exit;
}
else{
	//set $_POST["id"] as new variable named $id 
	$id=$_POST["id"];
}
 //query to update like count from "status" table and set the status id
$sql = "UPDATE status SET likes=likes+1 WHERE id='$id'";
$result = mysqli_query($connection, $sql);
//total like count in a table
$newLikesCount="SELECT likes FROM status WHERE id='$id'";

// no data returned, we just test for true(success)/false(failure):
if ($result) 
{
	if (mysqli_affected_rows($connection) == 1)
	{	// set the kind of data we're sending back and a success code
		header("Content-Type: application/json", NULL, 201);
		$response->result="Success";
	}
	else
	{	// set the kind of data we're sending back and an error response code
		header("Content-Type: application/json", NULL, 400);
	}
}
else
{	// set the kind of data we're sending back and an error response code
	header("Content-Type: application/json", NULL, 400);
}
//finished database, close connection
mysqli_close($connection);

// and send-->
echo json_encode($response);

?>