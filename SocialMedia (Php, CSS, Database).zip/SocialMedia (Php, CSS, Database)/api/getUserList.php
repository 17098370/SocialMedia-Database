<?php
//set the kind of data we're sending back 
	header("Content-Type: application/json");
	require_once "../credentials.php";
	
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	//create query to select all the username from "members" table
	$sql = "SELECT * from members";
	$result = mysqli_query($connection, $sql);
	$response = [];

	//set every row fetch from the result as response
	while ($row=mysqli_fetch_assoc($result)){
		$response[]=$row;
	}
	// and send-->
	echo json_encode($response);
?>

