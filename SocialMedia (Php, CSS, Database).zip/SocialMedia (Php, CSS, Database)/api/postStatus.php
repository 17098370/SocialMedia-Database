<?php
	//set the kind of data we're sending back 
	header("Content-Type: application/json");
	require_once "../credentials.php";
	//create 'empty' class that use when casting other types to objects
	$response=new \stdClass();
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	//get user's username
	//get status 
	$username=$_POST["username"];
	$status=$_POST["status"];

	//create query to see whether he is able to post or not able to post status
	//"Y" = able, "N"= not able
	$query= "SELECT username FROM profiles where avai ='Y' and username = '".$username."'";
	$filter = mysqli_query($connection, $query);

	//if there's a match
	if($filter->num_rows > 0){
		//insert data into the "status" table
		$sql = "INSERT INTO status VALUES (NULL,'$username','$status',now(),0)";
		$result = mysqli_query($connection, $sql);
		if ($result){
			if (mysqli_affected_rows($connection) == 1)
			{	
			// set the kind of data we're sending back and a success code
				header("Content-Type: application/json", NULL, 201);
				$response->result="Success";
			}
			else
			{	// set the kind of data we're sending back and an error response code
				$response->result="No Record Found";
				header("Content-Type: application/json", NULL, 400);
			}
		}

		else{
			//if no $result available
			$response->result="Error";
			$response->message=mysqli_error($connection);
		}
	// and send-->
	}
	else{	
		//means the person is being mute// avai="N"
        echo "<script type='text/javascript'>alert('You being mute!')</script>";
	}


// no data returned, we just test for true(success)/false(failure):
	
	echo json_encode($response);
?>