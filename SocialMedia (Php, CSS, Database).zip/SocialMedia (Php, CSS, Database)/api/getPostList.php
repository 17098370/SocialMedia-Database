<?php
//set the kind of data we're sending back 
	header("Content-Type: application/json");
	require_once "../credentials.php";
	
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	//create query to select all the details from "status" table,set order of the table where the date is more recent, and limit the table result with 10 rows
	$sql = "SELECT * from status order by set_date desc limit 10";
	$result = mysqli_query($connection, $sql);
	$response = [];

	//set every row fetch from the result as response
	while ($row=mysqli_fetch_assoc($result)){
		$response[]=$row;
	}
	// and send-->
	echo json_encode($response);
?>

