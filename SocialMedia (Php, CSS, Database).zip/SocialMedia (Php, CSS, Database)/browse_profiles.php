<?php
// execute the header and credentials script
// set the table name that execute in this page
require_once "header.php";
require_once "credentials.php";
$tableName= 'profiles';

if (!isset($_SESSION['loggedInSkeleton']))
{// user isn't logged in, display a message
echo<<<_END
    <container>
    <p>You must be logged in to view this page.<p>
    <img src="image/lock.ico">
    </container>
_END;
}
else
{   //connection between this page and database
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }   
    //Select details from the database
    $query = "SELECT username, firstname, lastname, age, email FROM ".$tableName." ";   
    $result = mysqli_query($connection, $query);
    //if theres any rows appear in the result 
    if(mysqli_num_rows($result) > 0){
        
        //html table that display user's information
echo<<<_END
        <br><br>
        <form>
        <table>
        <tr>
        <th><h3>Username</h3></th>
        <th><h3>First Name</h3></th>
        <th><h3>Last Name</h3></th>
        <th><h3>Age</h3></th>
        <th><h3>Email</h3></th>
        </tr>
_END;
        //Loop the $result, means every row of the databale will be display in here
        //Username will be link to the particular user's profile
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo '<td> <a href="show_profile.php?id='.$row['username'].'">'.$row['username'].'</a></td>';
                echo "<td>" . $row['firstname'] . "</td>";
                echo "<td>" . $row['lastname'] . "</td>"; 
                echo "<td>" . $row['age'] . "</td>"; 
                echo "<td>" . $row['email'] . "</td>"; 
            echo "</tr>";
        }
        echo "</table>";
        echo "</form>";
        
        mysqli_free_result($result);
    } else{
        //display if theres no any rows appear in the result
        echo "No records matching your query were found.";
    }

}

//finished database, close connection
mysqli_close($connection);

// finish off the HTML for this page
require_once "footer.php";
    
?>
