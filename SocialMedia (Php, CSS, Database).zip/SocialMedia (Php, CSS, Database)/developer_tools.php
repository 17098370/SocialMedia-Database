<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
<?php

// execute the header and credentials script
require_once "header.php";
require_once "credentials.php";

//set variable
$i = 0;
$notes = "";
$message ="";

if (!isset($_SESSION['loggedInSkeleton']))
{// user isn't logged in, display a message
echo<<<_END
    <container>
    <p>You must be logged in to view this page.<p>
    <img src="image/lock.ico">
    </container>
_END;
}

else
{
  // only display the page content if this is the admin account (all other users get a "you don't have permission..." message):
  if ($_SESSION['username'] == "admin")
  {     //connection between this page and database
        $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
        
     if (!$connection)
     {
    die("Connection failed: " . $mysqli_connect_error);
     }  
  
    }else{
      //normal user cannot access
         echo "You don't have permission to view this page...<br>";
    }
    //1st dropdown form that allow admin to *mute* user
    //use an HTTP POST request 
echo<<<_END
        <container>
        <form method="post">
        <fieldset>
          <legend>Mute a user</legend>
          <br>
          Username: <select id = "mute" class="form-dropdown" style="width:150px" name="mute">
          <option value=""> 
_END;
    //option value will take all the username from the profiles
    //every result will loop inside the option value
    $sql = "SELECT username FROM profiles";
    $filter = mysqli_query($connection, $sql);
    while($row=mysqli_fetch_array($filter))
    {
    echo"<option>".$row['username']."</option>";
    }

    //2nd dropdown form that allow admin to *unmute* user
    //use an HTTP POST request 
echo<<<_END
          <br><br><br>
          <input type="submit" value="Mute">
          <br>
          </fieldset>
        </form> 
        </container>
<br><br>
        <container>
        <form method="post">
        <fieldset>
          <legend>Unmute a user</legend>
          <br>
          Username: <select id = "unmute" class="form-dropdown" style="width:150px" name="unmute">
          <option value=""> 
_END;

    //option value will take all the username from the profiles
    //every result will loop inside the option value
    $sql = "SELECT username FROM profiles";
    $filter = mysqli_query($connection, $sql);
    while($row=mysqli_fetch_array($filter))
    {
    echo"<option>".$row['username']."</option>";
    }

echo<<<_END

        <br><br><br>
        <input type="submit" value="Unmute">
        <br>
        </fieldset>
        </form> 
        </container>
        <br><br><br>
_END;
//end of the mute and unmute dropdown form

//sticky note
echo<<<_END
  <container>
      <form action="developer_tools.php" method="POST">
        <fieldset>
          <legend>Post a sticky note on user's global feed:</legend>
          <br>
          Title <input id="titleInput" type="text" name="title" maxlength="50" style="width:1000px; height:40px;"required>
          <br><br>
          Content <input id="contentInput" type="text" name="notes" maxlength="140" style="width:100%; height:100px;" required> 
          <br><br>
          <div id="userCheckBox"></div>
          <input type="submit" value="Post" id="submitBut">
          <br>
        </fieldset>
      </form> 
  </container>
  <br><br>     
_END;
//end of sticky note

  //query start here
  //if got the post value from "mute" form
  if (isset($_POST['mute'])){
      //query create to UPDATE details from "profiles" table, set the availability from "Y" to "N" which the username is choosen in the "mute" form
        $sql= "UPDATE profiles SET avai = 'N' where username='".$_POST['mute']."';";
        $query = mysqli_query($connection,$sql);
        //display success message
        echo "<script type='text/javascript'>alert('Mute successfully!')</script>";

    }elseif (isset($_POST['unmute'])){
      //query create to UPDATE details from "profiles" table, set the availability from "N" to "Y" which the username is choosen in the "unmute" form
        $sql= "UPDATE profiles SET avai = 'Y' where username='".$_POST['unmute']."';";
        $query = mysqli_query($connection,$sql);
        //display success message
        echo "<script type='text/javascript'>alert('Unmute successfully!')</script>";

    }
    //end of mute and unmute features

        // query used to create graph 
        $query = "SELECT username, age, pets, sum(likes) FROM profiles JOIN status USING (username) GROUP BY username";
        $result = mysqli_query($connection, $query);

  //insert new notes into database
if (isset($_POST['notes']))
{ //connection between this page and database
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
  
  if (!$connection)
  {
    die("Connection failed: " . $mysqli_connect_error);
  } 
  
  //insert data into database
  //$sql = "INSERT INTO notes (username, status, set_date) VALUES ('$username[$i]', '$status[$i]','$set_date[$i]')";
  //$result = mysqli_query($connection, $sql);

  if ($result) 
    {//show successful message
      $message = "Successful<br>";
    } 
    else 
    {
      
      $message = "Failed, please try again<br>";
    }
    echo $message;
}


//HTML copy from google chart to create chart
echo<<<_END
<h1>Website statistic</h1>
<container>
<!--Load the AJAX API-->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
      
      // Load the Visualization API and the controls package.
      google.charts.load('current', {'packages':['corechart', 'table', 'gauge', 'controls']});

  // Set a callback to run when the Google Visualization API is loaded.    
  google.charts.setOnLoadCallback(drawMainDashboard);

      // Callback that creates and populates a data table,
      // instantiates a dashboard, a range slider and a pie chart,
      // passes in the data and draws it.
      function drawMainDashboard() {

    // Create a dashboard.
    var dashboard = new google.visualization.Dashboard(
        document.getElementById('dashboard_div'));


    // Create a slider.    
    var slider = new google.visualization.ControlWrapper({
      'controlType': 'NumberRangeFilter',
      'containerId': 'slider_div',
      'options': {
        'filterColumnIndex': 1,
        'ui': {
          'labelStacking': 'vertical',
          'label': 'Age Filter On Likes:'
        }
      }
    });
   
   // Create a pie chart.
     var pie = new google.visualization.ChartWrapper({
      'chartType': 'PieChart',
      'containerId': 'chart_div',
      'options': {
        'width': 300,
        'height': 300,
        'legend': 'none',
        'chartArea': {'left': 15, 'top': 15, 'right': 0, 'bottom': 0},
        'pieSliceText': 'label'
      },
      'view': {'columns': [0, 3]}
    });

    //Create a table to hold all user's data
    var table = new google.visualization.ChartWrapper({
      'chartType': 'Table',
      'containerId': 'table_div',
      'options': {
      }
    });

    // Create our data table.
    var data = google.visualization.arrayToDataTable([
      ['Name', 'Age', 'Pets', 'Total Likes Received'],
_END;
      //create loop to add all the query result into the table
      if($result->num_rows > 0){
          while($row = $result->fetch_assoc()){
            echo "['".$row['username']."', ".$row['age'].", ".$row['pets'].", ".$row['sum(likes)']."],";
          }
      }
    
echo<<<_END

        ]);
    dashboard.bind([slider], [pie, table]);
    dashboard.draw(data);
  }
</script>
  </head>

 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<div id="dashboard_div" style="border: 1px solid #ccc; margin-top: 1em">
  <table class="columns">
    <tr>
      <td>
        <div id="slider_div" style="padding-left: 15px"></div>
      </td>
      <td>
        <p>Filter</p>
      </td>
    </tr><tr>
      <td>
        <div id="chart_div" style="padding-top: 10px; "></div>
      </td><td>
        <div id="table_div" style="padding-top: 50px; padding-left: 100px; width :300px ; height :300px"></div>
      </td>
    </tr>
  </table>
</div>

</container>
<br><br>
_END;
   
}


// finish off the HTML for this page:
require_once "footer.php";

?>

<script>
  /*
    1. create function getUserList, this will link to "getUserList.php"
    2. This function will call all the username and then put every single username in checkbox
  */
  function getUserList(){
    $.get("api/getUserList.php").done(function(users){
        users.forEach(function(user){
        /*var option=document.createElement("input");
        option.attr("type","checkbox").attr("id",user.username).attr("value",user.username);*/
        var option=$("<input class='selectUser' type='checkbox' value='"+user.username+"'>"+user.username+"</input>");
        $(userCheckBox).append(option);
        $(userCheckBox).append("<br/>");
      })
    })
  }


/*
Run this script when everything is ready
1. Run getUserList function
2. Once the submit button is press, title, content and username will then saved as array
3. the values will go through "postNotes.php"
*/
  $(document).ready(function(){
    getUserList();
    $(submitBut).click(function(){
      var title=$(titleInput).val();
      var content=$(contentInput).val();
      var user=[];
      $('input[type=checkbox]:checked').each(function(){
        user.push($(this).val());
      })
      var data={
        title:title,
        content:content,
        user:user
      }
      $.post("api/postNotes.php",data).then(function(response){
        console.log(response)
      })
    })
  })
</script>