<?php
// execute the header script
	require_once "header.php";

echo<<<_END
	<container>
_END;

	if (!isset($_SESSION['loggedInSkeleton']))
	{// user isn't logged in, display a message
echo<<<_END
<container>
	<p>Dont miss out your friend. <br>
	<a href='sign_up.php'>click here</a> to sign up</h2><br>
    <img src="image/friend.jpg">
    </container>
_END;
	}
	else
	{
echo<<<_END
	<p>Welcome back! Did you <a href='set_profile.php'>set up your profile</a>?<p>
	<p>Remember to keep your profile update. :)<p>
	 <img src="image/friend.jpg">
_END;
	}


echo<<<_END
	</container>
_END;

	require_once "footer.php";

?>