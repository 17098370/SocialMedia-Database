SETUP:
1. run create_data.php
2. nagivate to login.php
3. username: admin// password: secret
4. open a new incognito windows with using normal username as below
	username: mandyb // password: abc123 OR
	username: barryg // password: letmein
* in order to see the google chart, please like the status to create number, becuase like is default as 0.*



DOCUMENTATION:


(a)sign in
- the user is required to enter username and password to sign in to the system.
- username and password that entered by the user will be check by the database, identify whether the records are matching with the database.
- if does not match, suggest user sign up or retry.



(b)sign up
- the user is required to enter username and password to sign up for the system.
- username and password that entered by the user will check by the database, to check the username is being used or not.
- if the username is not been used, the system will sign them up.



(c)helper
- helper included some useful functions that needed to the other pages.




(d)create data
- Create database, that is used in the system such as members table, profile tables and status table.
- members table: record user's username and password.
- profiles table: record user's profile such as firstname, lastname, age... 
- status table: record user's status, like count and date.
- notes table: record admin's sticky notes and particular user.



(e)header and footer
-the skeleton layout of the website




(f)global feed
- user able to see sticky note posted by admin
- user able to create a new status, like, and delete his own status.
- the user cannot delete other user's status, only admin allow to delete all the status.
- user that being mute is not able to post.



(g)set profile
- the user allows setting their own profile.
- which included their firstname, lastname, age, pets, email and dob
- every field enters by the user will be check.
- for example, firstname and lastname should be text form, age and pets should be an integer, email has email format and dob is a valid date.
- if the user already set up his profile, he can re-edit again by pressing submit button, new data will update in the database
- if the user never set up before, new data will be inserted into the database.




(h)show profile
- Showing the particular user's profile.




(i)browse profile
- user able to view all the users in the system.
- by clicking other user's name, it will bring him to the user's profile that he wants to see.




(j)developer tools
- only admin is approved to view this page.
- admin can mute and unmute user at this page
- admin can see all the statistic of the system 
- admin can send group message.

