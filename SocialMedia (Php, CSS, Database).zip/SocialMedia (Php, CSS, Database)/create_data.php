<?php

// Things to notice:
// This file is the first one we will run when we mark your submission
// Its job is to: 
// Create your database (currently called "skeleton", see credentials.php)... 
// Create all the tables you will need inside your database (currently it makes "members" and "profiles" tables, you will probably need more)... 
// Create suitable test data for each of those tables 
// NOTE: this last one is VERY IMPORTANT - you need to include test data that enables the markers to test all of your site's functionality

// read in the details of our MySQL server:
require_once "credentials.php";

// We'll use the procedural (rather than object oriented) mysqli calls

// connect to the host:
$connection = mysqli_connect($dbhost, $dbuser, $dbpass);

// exit the script with a useful message if there was an error:
if (!$connection)
{
	die("Connection failed: " . $mysqli_connect_error);
}
  
// build a statement to create a new database:
$sql = "CREATE DATABASE IF NOT EXISTS " . $dbname;

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Database created successfully, or already exists<br>";
} 
else
{
	die("Error creating database: " . mysqli_error($connection));
}

// connect to our database:
mysqli_select_db($connection, $dbname);

///////////////////////////////////////////
////////////// MEMBERS TABLE //////////////
///////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS members";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Dropped existing table: members<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE members (username VARCHAR(16), password VARCHAR(16), PRIMARY KEY(username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: members<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames[] = 'barryg'; $passwords[] = 'letmein';
$usernames[] = 'mandyb'; $passwords[] = 'abc123';
$usernames[] = 'mathman'; $passwords[] = 'secret95';
$usernames[] = 'brianm'; $passwords[] = 'test';
$usernames[] = 'angeline'; $passwords[] = 'aaa';
$usernames[] = 'a'; $passwords[] = 'test';
$usernames[] = 'b'; $passwords[] = 'test';
$usernames[] = 'c'; $passwords[] = 'test';
$usernames[] = 'd'; $passwords[] = 'test';
$usernames[] = 'admin'; $passwords[] = 'secret';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO members (username, password) VALUES ('$usernames[$i]', '$passwords[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

////////////////////////////////////////////
////////////// PROFILES TABLE //////////////
////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS profiles";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
	echo "Dropped existing table: profiles<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE profiles (username VARCHAR(16), firstname VARCHAR(40), lastname VARCHAR(50),age INT, pets TINYINT, email VARCHAR(50), dob DATE, avai VARCHAR(2) DEFAULT 'Y',PRIMARY KEY (username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: profiles<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'barryg'; $firstnames[] = 'Barry'; $lastnames[] = 'Grimes'; $age[] = 20; $pets[] = 5; $emails[] = 'baz_g@outlook.com'; $dobs[] = '1961-09-25';
$usernames[] = 'mandyb'; $firstnames[] = 'Mandy'; $lastnames[] = 'Brent'; $age[] = 10; $pets[] = 3; $emails[] = 'mb3@gmail.com'; $dobs[] = '1988-05-20';
$usernames[] = 'angeline'; $firstnames[] = 'lee'; $lastnames[] = 'yee'; $age[] = 33; $pets[] = 0; $emails[] = 'lee@jkaammss.com'; $dobs[] = '1998-02-10';
$usernames[] = 'admin'; $firstnames[] = 'admin'; $lastnames[] = 'lam'; $age[] = 23; $pets[] = 1; $emails[] = 'admin@gmail.com'; $dobs[] = '1997-04-24';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO profiles (username, firstname, lastname,age, pets, email, dob) VALUES ('$usernames[$i]', '$firstnames[$i]', '$lastnames[$i]', '$age[$i]', $pets[$i], '$emails[$i]', '$dobs[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}


///////////////////////////////////////////
////////////// STATUS TABLE ///////////////
///////////////////////////////////////////

/// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS status";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Dropped existing table: status<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE status (id INT(11) AUTO_INCREMENT PRIMARY KEY, username VARCHAR(16), status VARCHAR(5000), set_date DATETIME, likes INT DEFAULT 0)";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: status<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$id[] = ''; $username[] = 'barryg'; $status[] = 'im hungry'; $set_date = 'now()'; 
$id[] = ''; $username[] = 'mandyb'; $status[] = 'do not disturb'; $set_date = 'now()'; 
$id[] = ''; $username[] = 'angeline'; $status[] = 'secret shh'; $set_date = 'now()'; 
$id[] = ''; $username[] = 'admin'; $status[] = 'try'; $set_date = 'now()'; 

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	$sql = "INSERT INTO status (username, status, set_date) VALUES ('$username[$i]', '$status[$i]','$set_date[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}


////////////////////////////////////////////
//////////////// NOTES TABLE ///////////////
////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS notes";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
	echo "Dropped existing table: notes<br>";
} 
else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE notes (id INT(11) AUTO_INCREMENT PRIMARY KEY, title VARCHAR(10000), set_date DATETIME, content VARCHAR(150), user VARCHAR(16))";


// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: notes<br>";
}
else 
{
	die("Error creating table: " . mysqli_error($connection));
}

$id[] = ''; $title[] = 'No message available yet'; $set_date = 'now()';  $content[] = 'no message'; $user[]='mandyb'; 
$id[] = ''; $title[] = 'No message available yet'; $set_date = 'now()';  $content[] = 'no message'; $user[]='barryg';  

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($title); $i++)
{
	$sql = "INSERT INTO notes (id, title, set_date, content, user) VALUES ('$id[$i]', '$title[$i]','$set_date[$i]','$content[$i]','$user[$i]')";
	
	// no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}
	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

// we're finished, close the connection:
mysqli_close($connection);


?>