<?php


require_once "credentials.php";
require_once "helper.php";

// start/restart the session:
session_start();
echo <<<_END
<!DOCTYPE html>
<html>

<link rel="stylesheet" href="responsive.css" rel="stylesheet">
<style>


input[type=submit]{
    background-color:powderblue;
    border :none;
    color: white;
    padding: 10px 20px;
    margin: 4px 2px;
}

container{
  max-width: 1080px;
  padding-left: 40px;
  padding-right: 40px;
  width: 100%;
}
            
table, td, th {    
    border: 1px solid #ddd;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    text-align: center;
}

table {
    border-collapse: collapse;
    width: 100%;
    border-spacing: 0;
}

tr, th, td {
    padding: 15px;
    text-align:center;
    background-color: #fff
}

nav{
	margin-bottom: 0;
	text-align: center;
	padding-left:16px;
	letter-spacing: 2px;
}

h1{

    text-align: center;
    font-family: Apple Chancery, curvise ;
    color: powderblue;

}


.header-basic-light{
	padding: 20px 40px;
	box-sizing:border-box;
	box-shadow: 0 0 7px 0 rgba(0, 0, 0, 0.15);
	height: 80px;
	background-color: #fff;
}

.header-basic-light .header-limiter {
	max-width: 1200px;
	text-align: center;
	margin: 0 auto;

}



.header-basic-light .header-limiter a {
	color: #5c616a;
	text-decoration: none;
}

.header-basic-light .header-limiter nav{
	font:15px Arial, Helvetica, sans-serif;
	line-height: 40px;
	float: right;
}

.header-basic-light .header-limiter nav a{
	display: inline-block;
	padding: 0 5px;
	opacity: 0.9;
	text-decoration:none;
	color: #5c616a;
	line-height:1;
}

.header-basic-light .header-limiter nav a.selected {
	background-color: #86a3d5;
	color: #ffffff;
	border-radius: 3px;
	padding:6px 10px;
}


body {
	margin:0;
	padding:0;
	font-weight: 300;
}

</style>
<link rel="shortcut icon" href="image/favicon.png" />
<title>Social Network</title>
<body>

_END;


if (isset($_SESSION['loggedInSkeleton']))
{
	// THIS PERSON IS LOGGED IN
	// show the logged in menu options:
	// add an extra menu option if this was the admin:

echo<<<_END
<header class="header-basic-light">
    <div class ="header-limiter">
        <nav>
            <a href='about.php'><img src="image/home.png" style="width:20px;height:20px;"> About  </a>  
            <a href='set_profile.php'><img src="image/setting.png" style="width:20px;height:20px;">Set Profile  </a>  
            <a href='show_profile.php'><img src="image/show.png" style="width:20px;height:20px;">Show Profile  </a>  
            <a href='browse_profiles.php'><img src="image/friends.png" style="width:20px;height:20px;"> Browse Profiles  </a>  
            <a href='global_feed.php'><img src="image/news.png
            " style="width:20px;height:20px;"> Global Feed  </a>  
            <a href='libraries.php'> <img src="image/video.png" style="width:20px;height:20px;"> Video Sharing  </a>  
            <a href='sign_out.php'><img src="image/signin.jpg" style="width:20px;height:20px;"> Sign Out ({$_SESSION['username']})</a>
        </nav>
    </div>
</header>
_END;

	if ($_SESSION['username'] == "admin")
	{
echo<<<_END
		<header class="header-basic-light">
    	<div class ="header-limiter">
        <nav style="text-align: center;">

		<a href='developer_tools.php'><img src="image/tools.jpg" style="width:20px;height:20px;"> Developer tools </a>

        </nav>
    	</div>
		</header>
_END;

	}
}
else
{
	// THIS PERSON IS NOT LOGGED IN
	// show the logged out menu options:
	
echo <<<_END
<body>
<header class="header-basic-light">
    <div class ="header-limiter">
        <nav>
            <a href='about.php'><img src="image/home.png" style="width:20px;height:20px;">About</a> ||
            <a href='sign_up.php'><img src="image/signup.png" style="width:20px;height:20px;">Sign up</a> ||
            <a href='sign_in.php'><img src="image/signin.jpg" style="width:20px;height:20px;">Sign in</a>
        </nav>
    </div>
</header>
_END;
}

echo <<<_END
<br>
<h1>2CWK50: A Social Network</h1>
_END;
?>


