<?php

echo <<<_END
<br>

<style>

container{
    font-family:Courier New;
    text-align:center;
    padding:10px 20ps;
}

</style>
<container>
<footer>
&copy;6G5Z2107
</footer>
</container>
</body>
</html>
_END;
?>