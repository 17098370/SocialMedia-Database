<?php

// Things to notice:
// You need to add your recommendations for the video sharing component to this script
// You should use client-side code (i.e., HTML5/JavaScript/jQuery) to help you organise and present your analysis 
// For example, using tables, bullet point lists, images, hyperlinking to relevant materials, etc.

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInSkeleton']))
{
echo<<<_END
    <container>
    <p>You must be logged in to view this page.<p>
    <img src="image/lock.ico">
    </container>
_END;
}
else
{
?>

<style>
button.accordion {
    background-color: powderblue;
    color: black;
    cursor: pointer;
    padding: 30px;
    width: 100%;
    border: white;
    text-align: center;
    outline: white;
    font-weight: bold;
    font-size: 15px;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #ccc;
}


div.panel {
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}


.container {
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;
}

table {
	color: #333; /* Lighten up font color */
	font-family: Helvetica, Arial, sans-serif; /* Nicer font */
	width: '100%';
	border-collapse:
	collapse; border-spacing: 0;
}

td, th { 
	border: 2px solid #CCC; 
	height: 30px; 
	} /* Make cells a bit taller */

th {
	background: #F3F3F3;
	text-align: justify;
    text-justify: inter-word; /* Light grey background */
}

td {
	background: #FAFAFA; /* Lighter grey background */
	text-align: justify;
	text-justify: inter-word;/* Center our text */
}

div {
    text-align: justify;
    text-justify: inter-word;
}


</style>

<body>
	<div class = "container">

	<h2 align="center"><p> JavaScript video library recommendation </p></h2>
	<p align="center">Click on the buttons to open the collapsible content.</p>

	<button class="accordion">Introduction to JavaScript library</button>
	<div class="panel">
	  <p>A JavaScript "library" is a collection of JavaScript code written by other developers to address a recurring task. When it comes to choosing the right JavaScript library it certainly is a wild and confusing landscape out there. This guide will help you for budding front-end developer–navigate those murky waters when the time arrives to choose a video library suited for you. Each library I’ve chosen are the famouse library in the market. The document below will describe the brief of each video library.</p>
	</div>

	<button class="accordion">Suggested Libraries</button>
	<div class="panel">
	  <p>
		<ul align="center">
			<p><h1> <a href="http://videojs.com/"> Video.js </a><h1></p> 
			<img src="http://www.uicorner.com/wp-content/uploads/2014/04/videojs-open-source-html5-video-player.jpg"><br>
			<p><h1>	<a href="http://jplayer.org/"> jPlayer </a><h1></p>
			<img src="http://web.bogdanteodoru.com/wp-content/uploads/2012/04/jquery-html5-audio-video-player.jpg"><br>
			<p><h1>	<a href="http://www.chartjs.org/"> Popcorn.js </a><h1></p>
			<img src="https://i.pinimg.com/originals/40/f3/05/40f305ebeb0761a5ee5098bb07df43a9.jpg"><br>
		</ul>
	  </p>
	</div>

	<button class="accordion">Comparison between the Libraries</button>
	<div class="panel">
		<table align="justify">
			<tr>
				<th> Libraries </th>
				<th> Videojs </th>
				<th> jPlayer </th>
				<th> Popcorn.js </th>
			</tr>
			<tr>
				<th>Description</th>
				<th>Video.js is a web video player built from the ground up for an HTML5 world. It supports HTML5 and Flash video, as well as YouTube and Vimeo (through plugins). It supports video playback on desktops and mobile devices. This project was started mid-2010, and the player is now used on 200,000 websites. </th>
				<th>jPlayer is a completely free and open source (MIT) media library written in JavaScript. A jQuery plugin, (and Zepto) jPlayer allows you to rapidly weave cross platform audio and video into your web pages. jPlayer's comprehensive API allows you to create innovative media solutions while support and encouragement is provided by jPlayer's active and growing community.</th>
				<th>This is an HTML5 media framework which is written in JavaScript. It is a useful plugin for filmmakers, developers, designers and others to create time-based interactive media. This video jQuery plugin is a part of Mozilla's Popcorn project.</th>
			</tr>

			<tr>
				<th>Creator, Maintainess</th>
				<th>
					<ul>
						<li><a href="https://github.com/vhmth">Vinay</a></li>
						<li><a href="https://github.com/FirefoxMetzger">FirefoxMetzger</a></li>
						<li><a href="https://github.com/EhsanCh">Ehsan Chavoshi</a></li>
						<li><a href="https://github.com/shahlabs">Labdhi Shah</a></li>
						<p>Video.js 6.5.0 has released on 17th November 2017, it come shortly after release of 6.4.0, which has now been promoted latest.</p>
					</ul>
				</th>
				<th>Developed by <a href="http://www.happyworm.com/">Happyworm</a>. <br>Latest update on 27th November 2014</th>
				<th>Popcorn.js is part of Mozilla’s Popcorn project. This project is no longer maintained</th>
			</tr>
			
			<tr>
				<th> Documentation </th>
				<th> It is well documented in <a href="https://github.com/videojs/video.js">github</a>.</th>
				<th>It is well documented in its <a href="http://jplayer.org/latest/developer-guide/">website</a>. </th>
				<th>It is well documented in its <a href="http://mozilla.github.io/popcorn-docs/index.html">website</a>.</th>
			</tr>

			<tr>
				<th> Support available </th>
				<th> Supports are available on its<a href="http://docs.videojs.com/module-browser.html# "> official website</a> and <a href="https://github.com/videojs/video.js ">github</a>. </th>
				<th> Supports are available on its <a href="http://www.jplayer.org/">official website</a>. </th>
				<th> Support is available on its official <a href="http://mozilla.github.io/popcorn-docs/addon-development/">github</a> page. </th>
			</tr>

			<tr>
				<th> Integrated </th>
				<th> ** </th>
				<th> This plugin is an open source media library. It is written in JavaScript and is completely free. Users can quickly add a video or audio to a web page using jPlayer.</th>
				<th> Mozilla's HTML5 Video Framework. Popcorn.js is made-up of a core JavaScript library, and many plugins. </th>
			</tr>

			<tr>
				<th> Availability </th>
				<th> Free for user.</th>
				<th> Free for user.</th>
				<th> Free for user.</th>
			</tr>

			<tr>
				<th> Browser and Device Compatibility </th>
				<th> Compatibility for non-HTML5 browsers and devices should be the same as VfE. More details in Video.js <a href="https://github.com/videojs/video.js/wiki/Browser-and-Device-Compatibility">official github page.</a> </th>
				<th> Support Windows, OSC, iOS, Android and Blackberry version. More Details available in Jplayer <a href="http://jplayer.org/">official website.</a></th>
				<th> <a href="https://github.com/hapyak/popcorn.compatible">Popcorn-compatible </a>is not strictly required but is highly recommended to detect browser support and replace the plugin with a fallback when support is not available. Must be loaded before popcorn.inception.js. Browser compatibility can be found in <a href="http://happyworm.com/courses/popcorn-in-a-day/01/index-03.htm">here</a>. </th>
			</tr>
		</table>
	</div>
	<button class="accordion">Conclusion</button>
	<div class="panel">
	  <p>
		<ul align="justify">
			<p> As a conclusion, I recommend <strong><b><i><em>Videojs</em></i></b></strong> as the video library that can be use in the website. Videojs provided up-to-date support until now. Although jPlayer and Popcorn.js also provided well documented documentation, but for a fast developing of internet,  developers have to always improve the errors and bugs in order to stand out from the crowd. Videojs not only provide support on its official website but also its github page, has made users have more resource and solutions.</p> <br>
		</ul>
	  </p>
	</div>
		</table>
	  
	</div>

</body>
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].onclick = function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  }
}
</script>



<?php
}
// finish off the HTML for this page:
require_once "footer.php";
?>