<?php
// execute the header and credentials script
// set the table name that execute in this page
require_once "header.php";
require_once "credentials.php";
$tableName= 'members';

// default value we show in the form
$username = "";
$password = "";

// strings to hold any validation error messages
$username_val = "";
$password_val = "";

//dont show the sign_in form
$show_signup_form = false;

// message to output to user:
$message = "";

if (isset($_SESSION['loggedInSkeleton']))
{// if user is logged in, display a message:
	echo "You are already logged in, please log out first<br>";
	
}
elseif (isset($_POST['username']))
{//connection between this page and database
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}

	// SANITISATION
	$username = sanitise($_POST['username'], $connection);
	$password = sanitise($_POST['password'], $connection);

	// VALIDATION 
	$username_val = validateString($username, 1, 16);
	$password_val = validateString($password, 1, 16);
	
	// Concatenate all the validation results together
	$errors = $username_val . $password_val;
	
	if ($errors == "")
	{	//Insert new details to the database
		$query = "INSERT INTO members (username, password) VALUES ('$username', '$password');";
		$result = mysqli_query($connection, $query);
		
		// no data returned, we just test for true(success)/false(failure)
		if ($result) 
		{//show successful signup message
			$message = "Signup was successful, please sign in<br>";
		} 
		else 
		{
			// show the form
			// show an unsuccessful signup message
			$show_signup_form = true;
			$message = "Sign up failed, please try again<br>";
		}
			
	}
	else
	{	// validation failed, show the form again with guidance, unsuccessful signin message:
		$show_signup_form = true;
		$message = "Sign up failed, please check the errors shown above and try again<br>";
	}
	
	//finished database, close connection
	mysqli_close($connection);

}
else
{
	//normal visit to the page, show signup form
	$show_signup_form = true;
	
}


//form that allows users to sign up
if ($show_signup_form)
{

echo <<<_END
<style>
input[type=submit]{
    background-color:powderblue;
    border :none;
    color: white;
    padding: 10px 20px;
    margin: 4px 2px;
}

input[type=text] {
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

container{
    text-align:center;
    padding:10px 20px;
}

</style>



<container>
<form action="sign_up.php" method="post">
  <fieldset>
  <legend>Please choose a username and password:</legend>
  <br>
  Username: <input type="text" name="username" maxlength="16" value="$username" required> $username_val
  <br><br>
  Password: <input type="password" name="password" maxlength="16" value="$password" required> $password_val
  <br> <br>
  <input type="submit" value="Submit">
  <br>
  </fieldset>
</form>	
</container>
_END;
}


// display our message to the user
echo $message;

// finish off the HTML for this page
require_once "footer.php";

?>