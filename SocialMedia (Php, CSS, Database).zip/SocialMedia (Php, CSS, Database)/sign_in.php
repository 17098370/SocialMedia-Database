<?php
// execute the header and credentials script
// set the table name that execute in this page
require_once "header.php";
require_once "credentials.php";
$tableName= 'members';

// default value we show in the form
$username = "";
$password = "";

// strings to hold any validation error messages
$username_val = "";
$password_val = "";

//dont show the sign_in form
$show_signin_form = false;

// message to output to user:
$message = "";

if (isset($_SESSION['loggedInSkeleton']))
{	
	// if user is logged in, display a message:
	echo "You are already logged in, please log out first.<br>";

}
elseif (isset($_POST['username']))
{	//connection between this page and database
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}	
	
	// SANITISATION
	$username = sanitise($_POST['username'], $connection);
	$password = sanitise($_POST['password'], $connection);
	
	// VALIDATION
	$username_val = validateString($username, 1, 16);
	$password_val = validateString($password, 1, 16);
	
	// Concatenate
	$errors = $username_val . $password_val;
	if ($errors == "")
	{
        //check data from database
        $query = "SELECT username, password FROM ".$tableName." WHERE username = '".$username."' AND password = '".$password."'";
        $result = mysqli_query($connection, $query);
        $rows = mysqli_num_rows($result);
        
        //if data return
		if ($rows > 0 )
		{// fake a match with the database table
			$n = 1;	 
		}
		else
		{
			$n = 0;
		}
			
		//if there's a match, set session variables and display success message
		if ($n > 0)
		{
			$_SESSION['loggedInSkeleton'] = true;
			$_SESSION['username'] = $username;
echo<<<_END
<container>
	<p>Hi, $username, you have successfully logged in, please <a href='show_profile.php'> Click here to enter website </a></p><br>
</container>
_END;
		}
		else
		{//form will appear *when no matching credentials* and display fail message
			$show_signin_form = true;
			$message = "Sign in failed, please try again <br>";
		}
		
	}
	else
	{//form will appear *when validation fail*, display message to user
		$show_signin_form = true;
		$message = "Sign in failed, please check the errors shown above and try again<br>";
	}
	//finished database, close connection
	mysqli_close($connection);

}
else
{	
	//user enter page for the first time
	$show_signin_form = true;
}

//form to let user sign in
if ($show_signin_form)
{
echo <<<_END
<container>
<form action="sign_in.php" method="post">
<fieldset>
  <legend>Please enter your username and password:</legend>
  <br>
  Username: <input type="text" name="username" maxlength="16" value="$username" required> $username_val
  <br><br>
  Password: <input type="password" name="password" maxlength="16" value="$password" required> $password_val
  <br><br>
  <input type="submit" value="Submit">
  <br>
  </fieldset>
</form>	
</container>
_END;
}

// display our message to the user
echo $message;

// finish off the HTML for this page
require_once "footer.php";

?>
