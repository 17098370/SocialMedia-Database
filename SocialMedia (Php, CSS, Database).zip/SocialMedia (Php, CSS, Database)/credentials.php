<?php
// default values for Xampp:
$dbhost  = 'localhost';
$dbuser  = 'root';
$dbpass  = '';
$dbname  = 'skeleton';

?>