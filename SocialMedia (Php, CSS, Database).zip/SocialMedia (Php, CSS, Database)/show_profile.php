<?php
// execute the header and credentials script
require_once "header.php";
require_once "credentials.php";

if (!isset($_SESSION['loggedInSkeleton']))
{// user isn't logged in, display a message
echo<<<_END
    <container>
    <p>You must be logged in to view this page.<p>
    <img src="image/lock.ico">
    </container>
_END;
}
else
{	//read their username from the session	
	//connection between this page and database
	$username = $_SESSION["username"];
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}

	//get the user's id from what user press on (username)
	if(isset($_GET['id'])){
		$username = $_GET['id'];
	}

	//query to select all the detials from a particular username that user click
	//check how many row come back
	$query = "SELECT * FROM profiles WHERE username='$username'";
	$result = mysqli_query($connection, $query);
	$n = mysqli_num_rows($result);
		
	// if there was a match
	if ($n > 0)
	{	// use the identifier to fetch one row as an associative array (elements named after columns)
		$row = mysqli_fetch_assoc($result);
echo <<<_END

        <container>
        <form>
        <fieldset>
        <legend>My Profile </legend>
       
_END;
        // display their profile data
		echo "<br><br>First name: {$row['firstname']}<br><br>";
		echo "Last name: {$row['lastname']}<br><br>";
        echo "Age: {$row['age']}<br><br>";
		echo "Number of pets: {$row['pets']}<br><br>";
		echo "Email address: {$row['email']}<br><br>";
		echo "Date of birth: {$row['dob']}<br><br>";
        
echo <<<_END

        </fieldset>
        </form>
        </container>

_END;

	}
	else
	{//tell user that he have not set up a profile, and link to "set.profile.php"
echo<<<_END
<container>
	<p>Uh oh..You still need to <a href='set_profile.php'>set up your profile</a>!<br><br><br>
	<img src="image/sad.png"></p>
</container>
_END;

	}
	//finished with the database, close the connection
	mysqli_close($connection);
		
}

// finish off the HTML for this page
require_once "footer.php";
?>