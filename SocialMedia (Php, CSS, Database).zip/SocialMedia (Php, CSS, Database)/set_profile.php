<?php
// execute the header script
require_once "header.php";

// default values we show in the form:
$firstname = "";
$lastname = "";
$age = "";
$pets = "";
$email = "";
$dob = "";

// strings to hold any validation error messages
$firstname_val = "";
$lastname_val = "";
$age_val = "";
$pets_val="";
$email_val = "";
$dob_val = "";

//dont show the show_profile_form form
$show_profile_form = false;

// message to output to user:
$message = "";

if (!isset($_SESSION['loggedInSkeleton']))
{// user isn't logged in, display a message
echo<<<_END
    <container>
    <p>You must be logged in to view this page.<p>
    <img src="image/lock.ico">
    </container>
_END;
}
elseif (isset($_GET['firstname'])) //if the values is from the user
{	//connection between this page and database
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	// SANITISATION CODE :
	$firstname = sanitise($_GET['firstname'], $connection);
	$lastname = sanitise($_GET['lastname'], $connection);
    $age= filter_var($_GET['age'], FILTER_SANITIZE_NUMBER_INT);
	$pets= filter_var($_GET['pets'], FILTER_SANITIZE_NUMBER_INT);
	$email = filter_var($_GET['email'], FILTER_SANITIZE_EMAIL);
	$dob = filter_var($_GET['dob'], FILTER_SANITIZE_STRING);

    // VALIDATION
 	$firstname_val =  validateString($firstname, 1, 40);
	$lastname_val =  validateString($lastname, 1, 50);
    $age_val = validateInt($age, 0 , 128);
	$pets_val = validateInt($pets, 0 , 100);
    $email_val = validateEmail($email);
    $dob_val = validateDate($dob);

    // Concatenate
	$errors = $firstname_val . $lastname_val . $age_val . $pets_val . $email_val . $dob_val ;
	

	if ($errors == "")
	{	//read their username from the session	
		$username = $_SESSION["username"];
		//query check to see if this user already had a set the profile
		$query = "SELECT * FROM profiles WHERE username='$username'";
		$result = mysqli_query($connection, $query);
		$n = mysqli_num_rows($result);

		//check if there's row come back or not
		if ($n > 0)
		{	//if theres row appear, means the user had set the profile before. Now update the details to "profiles" table
			$query = "UPDATE profiles SET firstname='$firstname',lastname='$lastname',age='$age',pets='$pets',email='$email',dob='$dob' WHERE username='$username'";
			$result = mysqli_query($connection, $query);		
		}
		else
		{ //means the user never set profile before
			//insert new data into the "profiles" table
			$query = "INSERT INTO profiles (username,firstname,lastname,age,pets,email,dob) VALUES ('$username','$firstname','$lastname','$age',$pets,'$email','$dob')";
			$result = mysqli_query($connection, $query);	
		}

		//nodata returned, test for true(success)/false(failure)
		if ($result) 
		{	
			// show a successful update message
			echo<<<_END
			<container>
			<p>Profile successfully updated</p>
			</container>
_END;
		} 
		else
		{	// show the set profile form and an unsuccessful update message
			$show_profile_form = true;
			$message = "Update failed<br>";
		}
	}
	else
	{
		// validation failed, show the form again with an unsuccessful update message
		$show_profile_form = true;
		$message = "Update failed, please check the errors above and try again<br>".$errors;
	}
	//finished with the database, close the connection
	mysqli_close($connection);

}
else
{	//user enter the page for the first time,  show any data already in the table
	//read username from session
	$username = $_SESSION["username"];

	//connection between this page and database
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}

	// check for a row in our profiles table with a matching username and return data
	//check how many row come back
	$query = "SELECT * FROM profiles WHERE username='$username'";
	$result = mysqli_query($connection, $query);
	$n = mysqli_num_rows($result);
	
	// if there was a match then extract their profile data	
	if ($n > 0)
	{
		// use the identifier to fetch one row as an associative array (elements named after columns):
		$row = mysqli_fetch_assoc($result);
		$firstname = $row['firstname'];
		$lastname = $row['lastname'];
        $age = $row['age'];
		$pets = $row['pets'];
		$email = $row['email'];
		$dob = $row['dob'];
	}
	// show the set profile form
	//finished with the database, close the connection
	$show_profile_form = true;
	mysqli_close($connection);
	
}

if ($show_profile_form)
{
echo <<<_END

<!-- CLIENT-SIDE VALIDATION MISSING -->
<container>
<form action="set_profile.php" method="get">
  <fieldset>
  <legend>Update your profile info:</legend><br><br>
  First name: <input type="text" name="firstname" maxlength="40" value="$firstname" required> $firstname_val
  <br><br>
  Last name: <input type="text" name="lastname" maxlength="50" value="$lastname" required> $lastname_val 
  <br><br>
  Age: <input type="number" name="age"  min="0" max="130" value="$age" required> $age_val
  <br><br>
  Number of pets: <input type="number" min="0" max="100" name="pets" value="$pets" required>
  <br><br>$pets_val
  Email address: <input type="email" maxlength="50" name="email" value="$email" required> $email_val
  <br><br>
  Date of birth: <input type="date" name="dob" min="1899-04-01" max="2017-12-12" value="$dob" required>
  <br><br> $dob_val
  <input type="submit" value="Submit">
  </fieldset>
</form>	
</container>
_END;
}

// display our message to the user
echo $message;

// finish off the HTML for this page
require_once "footer.php";
?>